---
title: Check2 square
layout: icon
categories:
  - UI and keyboard
tags:
  - checkmark
  - todo
  - select
  - done
  - checkbox
---
