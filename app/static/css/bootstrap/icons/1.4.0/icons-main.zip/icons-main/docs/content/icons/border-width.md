---
title: Border width
categories:
  - Typography
tags:
  - borders
  - wysiwyg
---
