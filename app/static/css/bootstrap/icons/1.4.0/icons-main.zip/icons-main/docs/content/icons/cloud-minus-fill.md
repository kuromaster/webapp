---
title: Cloud minus fill
categories:
  - Clouds
tags:
  - subtract
---
